#!/bin/bash
# A lancer une seule fois, avant le premier demarrage.
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/moteur.sh
detecter_moteur

echo "== 1. Fichier .env =="
if [ ! -f .env ]; then
  cp .env.example .env
  echo "   .env cree depuis .env.example. Changez les mots de passe avant de continuer."
else
  echo "   .env existe deja, inchange."
fi
set -a; source .env; set +a

echo "== 2. vm.max_map_count =="
actuel=$(sysctl -n vm.max_map_count 2>/dev/null || echo 0)
if [ "$actuel" -lt 262144 ]; then
  echo "   actuel : ${actuel}, insuffisant. L'indexeur refusera de demarrer."
  aide_max_map_count
  echo "   Sous Windows, la valeur lue ici est celle de la VM, pas celle de Windows."
  exit 1
fi
echo "   ${actuel}, suffisant."

if est_rootless; then
  echo "== 2b. Podman rootless detecte =="
  echo "   Le compose ne demande aucune limite memlock ni nofile elevee,"
  echo "   donc rien a faire. Si vous voyez 'setrlimit: Operation not permitted',"
  echo "   c'est que le docker-compose.yml a ete modifie."
fi

echo "== 3. Mot de passe d'enrolement des agents =="
printf '%s' "${AGENT_ENROLLMENT_PASSWORD}" > config/wazuh/manager/authd.pass
chmod 600 config/wazuh/manager/authd.pass
echo "   config/wazuh/manager/authd.pass ecrit (non commite)."

echo "== 4. Certificats =="
if [ -f config/wazuh_indexer_ssl_certs/root-ca.pem ]; then
  echo "   deja generes, on garde."
else
  # Lance a la main, hors du cycle 'up' : voir le commentaire du service
  # generator dans docker-compose.yml.
  $CE --profile setup run --rm generator
  cp config/wazuh_indexer_ssl_certs/root-ca.pem \
     config/wazuh_indexer_ssl_certs/root-ca-manager.pem
  echo "   generes."
fi

echo
echo "Pret. Demarrage : ./scripts/demarrer.sh"
